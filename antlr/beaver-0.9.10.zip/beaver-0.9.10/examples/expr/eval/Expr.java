package expr.eval;

class Expr extends beaver.Symbol
{
	final double val;

	Expr(double val)
	{
		super();
		this.val = val;
	}
}
